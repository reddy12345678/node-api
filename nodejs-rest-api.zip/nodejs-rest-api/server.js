'use strict'
//
const hive = require('hive-driver');
var express = require('express')
var app = express()

// Hive server connection details
const host = 'your-hive-server';  // Replace with your Hive server address
const port = 10000;               // Default port for HiveServer2
const username = 'your-username'; // Replace with your Hive username
const password = 'your-password'; // Replace with your Hive password (if needed)

// Create a Hive connection
const connection = hive.createConnection({
  host: host,
  port: port,
 // username: username,
 // password: password,
  database: 'default', // You can specify the database you want to use
});

app.set("port", process.env.PORT || 4000)

app.get('/', function (req, res) {
  connection.connect((err) => {
    if (err) {
      console.error('Error connecting to Hive:', err);
      return;
    }
  
    console.log('Successfully connected to Hive.');
  
    // Run a query
    const query = 'SELECT * FROM your_table LIMIT 10'; // Replace with your query
    connection.query(query, (err, results) => {
      if (err) {
        console.error('Error executing query:', err);
        return;
      }
  
      console.log('Query results:', results);
      connection.end();
    });
  });
})


const server = app.listen(app.get("port"), function () {
  const host = server.address().address
  const port = server.address().port

  console.log("Node.js API app running at http://%s:%s", host, port)
})

process.on('SIGINT', () => {
  console.log('Received SIGINT. Closing server...')
  server.close(() => {
    console.log('Server closed. Exiting process...')
    process.exit(0)
  })
})

process.on('SIGTERM', () => {
  console.log('Received SIGTERM. Closing server...')
  server.close(() => {
    console.log('Server closed. Exiting process...')
    process.exit(0)
  })
})
